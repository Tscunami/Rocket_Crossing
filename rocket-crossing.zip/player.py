from turtle import Turtle
import turtle

STARTING_POSITION = (0, -280)
MOVE_DISTANCE = 10
FINISH_LINE_Y = 280


class Player(Turtle):

    def __init__(self):
        super().__init__()
        turtle.register_shape("rocket.gif")
        self.shape("rocket.gif")
        self.shapesize(stretch_wid=0.2, stretch_len=0.2)
        self.penup()
        self.goto(STARTING_POSITION)
        self.setheading(90)
        self.color("white", "MediumSpringGreen")

    def move(self):
        self.forward(MOVE_DISTANCE)

    def new_level(self):
        self.goto(STARTING_POSITION)

    def in_finish(self):
        if self.ycor() > FINISH_LINE_Y:
            self.new_level()
            return True
        else:
            return False
